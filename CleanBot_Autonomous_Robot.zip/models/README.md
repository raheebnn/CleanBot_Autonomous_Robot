# Models

Trained model files are intentionally not included in this repository by default.

Place your own model files here and document:
- model architecture
- training dataset
- training code/source
- model version
- license/redistribution permission

Do not commit private, proprietary, or third-party model files without permission.
