# Calibration Files

## webcam_fixed_v3.yaml

This ORB-SLAM3 camera/IMU configuration is for a Pi Camera 3 at 640x480 and 25 FPS, with MPU-6050 IMU data at 100 Hz.

The supplied configuration contains:
- Camera intrinsics (fx, fy, cx, cy)
- Camera resolution and frame rate
- ORB feature extractor settings
- MPU-6050 IMU noise parameters
- Camera-to-IMU extrinsic transform (`Tbc`)
- 15-degree camera tilt and 0.04 m translation used by the supplied configuration

Use this YAML with the matching ORB-SLAM3 vocabulary/system configuration.

The file is included as part of the project's calibration/configuration data and should be kept consistent with the physical camera and IMU mounting.
